# Coray Trip 安装包 0.3.0

此包包含 skill 与远程 MCP 配置模板，不含账号、密码、token、App ID、授权、行程数据或服务器程序。原 0.2.1 导出中的内容规则仍保留；0.3.0 增加多用户 OAuth 工作流并移除安装专用地址。

## 给自己的 dot 的安装口令

请先阅读本包及 skills/manage-trips/references/setup-and-pitfalls.zh-CN.md，检查当前宿主是否支持官方插件导入以及是否已有同名连接。请让我私下提供服务所有者确认的 HTTPS 服务器地址，在私有安装副本的 mcp.json 中仅替换示例 URL（末尾保留 /mcp），不要公开发布真实地址。使用我自己的现有已批准账号，通过安全 OAuth 窗口由我本人登录和确认。不要复制别人的连接、凭据或 App 绑定，不替我新建账号、改角色或成员。先验证实际工具 schema 和只读 list_trips/get_trip，逐项报告已完成与未验收的阶段。

## 最少步骤

1. 解压到私有位置；`https://trips.example.org/mcp` 是保留示例，不能直接连接。把 mcp.json 的 url 改为服务所有者私下确认的实际 HTTPS MCP 地址。不要改 DCR、回调或身份。
2. 通过当前宿主支持的插件创建/导入流程安装。没有入口时报告宿主限制；ZIP 不会自动安装。已存在相同连接时用其受支持更新流程，不断开重建。
3. 服务端须启用独立账号模式。保留原单用户设置，不能把它改指向收件人。收件人须自行登录并同意，网页已登录不等于 MCP 已同意。
4. Member/viewer 获得 trips:read，仅 list_trips、get_trip、export_trip；Content manager 请求管理时获得 trips:manage，保留六工具。管理请求会按 Member 身份降为只读并在确认页及响应披露实际 scope。不能为连接而提升角色。
5. 核对实际工具与字段，先只读验证。列表为空可能是没有成员行程。不要猜 ID；不要通过写入测试认证。

传输为 Streamable HTTP；OAuth public-client DCR、PKCE S256；无 client secret。模板保留 trips:manage 请求以兼容既有包，服务器按当前角色限制；需要明确只读的私有安装副本可把 baseScopes 改为 ["trips:read"]。不同用户使用各自的连接、登录和授权；既有连接无需为服务器兼容升级重做同意。

## 验收与限制

实现的双账号 HTTP/官方 SDK 测试与本地 Chrome 试验不代表收件人已经安装或同意。实际宿主导入、scope 降级兼容性、工具 schema、本人 OAuth 和只读调用须分别验收。不支持任意回调；当前服务允许 https://chatgpt.com/connector_platform_oauth_redirect。不支持 CIMD。90 天授权到期需本人重新明确同意，refresh 不延长期限。

包版本、服务版本和宿主导入的 schema 是不同对象。使用同一 App 的 Manage → Reload tools/Refresh 保留身份与授权，再检查新的目标会话；不要为补字段创建替代连接。查看 PACKAGE-STATUS.md 与 setup-and-pitfalls.zh-CN.md 获取证据边界及排障。

官方安装入口以当前宿主能力为准：https://help.openai.com/en/articles/20001256-plugins-in-chatgpt
格式说明：https://agent-plugins.org/

公开包只含示例地址；不得把私有配置、密码、回调 code/state、token 或行程内容加入包或聊天。
